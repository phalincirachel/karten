#!/usr/bin/env python3
"""Einmaliges, wiederholbares Einbauen der Akkord-Mystery-Kategorie in index.html.
Im Projektordner ausführen: python3 einbauen.py
"""
from pathlib import Path
import re

index=Path('index.html')
if not index.is_file():
    raise SystemExit('Fehler: Im Ordner muss die ursprüngliche index.html liegen.')
html=index.read_text(encoding='utf-8')
if 'HARMONY_QUIZ.mount' in html:
    # Ein bereits installiertes Paket erhält beim erneuten Aufruf einen
    # aktualisierten Cache-Schlüssel, ohne die Karte ein zweites Mal einzubauen.
    revised=re.sub(r'harmonie-quiz\.css\?v=\d+', 'harmonie-quiz.css?v=2', html)
    revised=re.sub(r'harmonie-quiz\.js\?v=\d+', 'harmonie-quiz.js?v=2', revised)
    if revised != html:
        index.write_text(revised,encoding='utf-8')
        print('Bestehende Akkordkarte: Verweise auf die neue Version aktualisiert.')
    else:
        print('Akkord-Mystery ist bereits eingebaut und aktuell.')
    raise SystemExit(0)

# Anker prüfen, bevor etwas geändert wird.
anchors=[
    '  </style>',
    '  <script>\n    (() => {',
    'article.append(opener,ratingSection(card));return article}',
    'detail.querySelector(".detail-category")?.replaceWith(ratingSection(card,"detail-rating"));',
]
for anchor in anchors:
    if anchor not in html:
        raise SystemExit(f'Einbau abgebrochen: Erwarteter Codeabschnitt fehlt: {anchor[:65]!r}')

html=html.replace('  </style>', '    <link-placeholder>\n  </style>',1)
# stylesheet bewusst außerhalb des style-Elements einfügen
html=html.replace('    <link-placeholder>\n  </style>',
    '  </style>\n  <link rel="stylesheet" href="harmonie-quiz.css?v=2">',1)
html=html.replace('  <script>\n    (() => {',
    '  <script src="harmonie-quiz.js?v=2"></script>\n  <script>\n    (() => {',1)
html=html.replace('article.append(opener,ratingSection(card));return article}',
    'article.append(opener,ratingSection(card));'
    'if(card.kind==="harmony-quiz"){article.classList.add("harmony-card");window.HARMONY_QUIZ.mount(article,false)}'
    'return article}',1)
anchor='detail.querySelector(".detail-category")?.replaceWith(ratingSection(card,"detail-rating"));'
html=html.replace(anchor,anchor+'\n'
    '        if(card.kind==="harmony-quiz"){\n'
    '          detail.querySelector(".detail-media")?.remove();\n'
    '          detail.querySelector(".google-search")?.remove();\n'
    '          detail.querySelector(".detail-text")?.remove();\n'
    '          window.HARMONY_QUIZ.mount(detail,true);\n'
    '        }',1)
# Audiowiedergabe beenden, wenn die Detailansicht geschlossen wird.
anchor='dialog.addEventListener("close",()=>document.body.classList.remove("dialog-open"));'
if anchor in html:
    html=html.replace(anchor,anchor+'dialog.addEventListener("close",()=>window.HARMONY_QUIZ.stop());',1)
index.write_text(html,encoding='utf-8')
print('index.html ergänzt: Die bestehenden Karten bleiben unverändert.')
