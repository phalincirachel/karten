AKKORD-MYSTERY FÜR DIE KARTEI
============================
Quellprojekt: https://github.com/phalincirachel/karten

IN DER KARTEI EINBAUEN
1. Die drei Dateien harmonie-quiz.js, harmonie-quiz.css und einbauen.py
   in das Stammverzeichnis des Kartenprojekts legen (neben index.html).
2. Im Stammverzeichnis ausführen:
     python3 einbauen.py
3. Diese drei Dateien und die geänderte index.html committen und nach
   GitHub pushen. GitHub Pages veröffentlicht danach die neue Version.

Die Einbauroutine prüft die exakten Anker der veröffentlichten
index.html und verändert vorhandene Karten und Kategorien nicht.

VORSCHAU
Die Datei akkord-mystery-demo.html kann einzeln im Browser geöffnet
werden. Sie enthält CSS und JavaScript bereits vollständig eingebettet.

FUNKTION
Jede Folge besteht aus C-Dur, zwei unabhängig gewählten zufälligen
Dur- oder Mollakkorden, C-Dur. Je Zwischenposition stehen 11 Grundtöne
(x Dur oder Moll) und drei Umkehrungen zur Verfügung, also 66 Optionen.
Somit gibt es 66² = 4356 mögliche bezeichnete Akkordfolgen.

Die Wiedergabe setzt den Bass als vierte Stimme. Die drei oberen Stimmen
enthalten jeweils Grundton, Terz und Quinte. Die Stimmführung wird
anhand von Stimmumfang, Stimmkreuzungen, Tonabständen, gemeinsamen Tönen,
großen Sprüngen und parallelen Quinten/Oktaven optimiert. Der Grundton
C ist als Zwischenakkord ausgeschlossen (in Dur und Moll).

Der Klang wird vollständig per Web Audio im Browser erzeugt.
Ein Wiedergabeklick (auch auf iPhone) ist erforderlich.

HINWEIS
Die öffentlich erreichbare GitHub-Pages-Seite wird durch dieses
Dateipaket allein noch nicht verändert. Dazu ist ein Push ins
GitHub-Repository erforderlich.

NEU IN VERSION 2
- Klang-, Spielweise- und Temporegler übernehmen Auswahlwerte nun korrekt.
- Nach „Ergebnis zeigen“ erscheint eine zweizeilige Partitur mit
  Violin- und Bassschlüssel für alle vier Akkorde in einer Zeile.
- Tiefe obere Stimmen werden in den Bassschlüssel geschrieben.
- Die Partitur wird mit VexFlow 5 gerendert, sobald die öffentlich
  erreichbare Bibliothek geladen wurde. Offline erscheint ein
  eigenständiger SVG-Notensatz für dieselben MIDI-Tonhöhen.
- Akkordsymbole: C, F/A, H-/D; das deutsche B heißt B♭.
- Die Notenzeile ist auf schmalen Bildschirmen seitlich verschiebbar.
- Zusätzlich zur bisherigen Kartenansicht zeigt die standalone-Vorschau
  die Karte gleich in einer breiten, übersichtlichen Ansicht.
