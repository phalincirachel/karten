/* Kartei-Erweiterung: Akkord-Mystery. Keine externen Abhängigkeiten. */
(function (global) {
  "use strict";
  const CATEGORY = "Akkord-Mystery";
  const ROOTS = {
    major: {
      1: ["Des", "F", "As"], 2: ["D", "Fis", "A"], 3: ["Es", "G", "B"],
      4: ["E", "Gis", "H"], 5: ["F", "A", "C"], 6: ["Fis", "Ais", "Cis"],
      7: ["G", "H", "D"], 8: ["As", "C", "Es"], 9: ["A", "Cis", "E"],
      10: ["B", "D", "F"], 11: ["H", "Dis", "Fis"]
    },
    minor: {
      1: ["Cis", "E", "Gis"], 2: ["D", "F", "A"], 3: ["Es", "Ges", "B"],
      4: ["E", "G", "H"], 5: ["F", "As", "C"], 6: ["Fis", "A", "Cis"],
      7: ["G", "B", "D"], 8: ["Gis", "H", "Dis"], 9: ["A", "C", "E"],
      10: ["B", "Des", "F"], 11: ["H", "D", "Fis"]
    }
  };
  const C_CHORD = {root:0, quality:"major", inversion:0, pcs:[0,4,7], names:["C","E","G"], label:"C"};
  const voiceLabels = ["Bass", "Tenor", "Alt", "Sopran"];
  let quiz = null, quizSequence = 0;
  const settings = {bpm:86, timbre:"piano", mode:"block", repeat:false};
  const views = new Set();
  let ctx = null, ambient = null, playBus = null, timers = [], playing = false, activeStep = -1, epoch = 0;

  function randInt(max) {
    if (global.crypto && typeof global.crypto.getRandomValues === "function") {
      const a = new Uint32Array(1), bound = Math.floor(0x100000000/max)*max;
      do { global.crypto.getRandomValues(a); } while (a[0] >= bound);
      return a[0] % max;
    }
    return Math.floor(Math.random() * max);
  }
  const pc = x => ((x%12)+12)%12;
  const notePitch = (root, interval) => pc(root+interval);
  function chord(root, quality, inversion) {
    if (root===0) return {...C_CHORD};
    const names = ROOTS[quality][root], pcs=[root, notePitch(root, quality==="major"?4:3), notePitch(root,7)];
    return {root,quality,inversion,pcs,names,
      label:`${noteNameShown(names[0])}${quality==="minor"?"-":""}${inversion?"/"+noteNameShown(names[inversion]):""}`};
  }
  function randomMiddle() { return chord(1+randInt(11),randInt(2)?"major":"minor",randInt(3)); }
  function bassPc(c) { return c.pcs[c.inversion]; }
  function candidatePitches(pitchClass,min,max) {
    const out=[]; for(let n=min;n<=max;n++) if(pc(n)===pitchClass) out.push(n); return out;
  }
  function permutations(arr) {
    return [[arr[0],arr[1],arr[2]],[arr[0],arr[2],arr[1]],
      [arr[1],arr[0],arr[2]],[arr[1],arr[2],arr[0]],
      [arr[2],arr[0],arr[1]],[arr[2],arr[1],arr[0]]];
  }
  function voicings(c,final=false) {
    const bass = final?[48]:candidatePitches(bassPc(c),41,55), result=[];
    const perm = permutations(c.pcs);
    for(const b of bass) for(const pitches of perm) {
      for(const t of candidatePitches(pitches[0],52,65)) {
        if(t<=b+4 || t-b>23)continue;
        for(const a of candidatePitches(pitches[1],57,72)) {
          if(a<=t+2 || a-t>12)continue;
          for(const s of candidatePitches(pitches[2],62,79)) {
            if(s<=a+2 || s-a>12)continue;
            result.push([b,t,a,s]);
          }
        }
      }
    }
    // Einige Akkordlagen sind bei weit entfernten Tonarten recht eng; die Bereiche
    // enthalten dennoch für jede der zwölf Tonklassen passende vierstimmige Sätze.
    return result;
  }
  function staticCost(v) {
    const centers=[48,56,63,69], weights=[.1,.1,.08,.08];
    return v.reduce((sum,n,i)=>sum+Math.abs(n-centers[i])*weights[i],0);
  }
  function transition(prev,next) {
    let cost=0;
    const weights=[1.25,1.05,1.15,1.5];
    for(let i=0;i<4;i++) {
      const leap=Math.abs(next[i]-prev[i]);
      cost+=leap*weights[i]+Math.pow(Math.max(0,leap-(i===0?7:5)),2)*.36;
    }
    // Gleichgerichtete parallele reine Quinten und Oktaven vermeiden.
    for(let a=0;a<4;a++)for(let b=a+1;b<4;b++) {
      const before=pc(prev[b]-prev[a]), after=pc(next[b]-next[a]);
      const da=next[a]-prev[a],db=next[b]-prev[b];
      if ((before===0||before===7) && before===after && da*db>0) cost+=11;
    }
    return cost;
  }
  function voiceLead(chords) {
    const start=[48,55,60,64];
    const candidates=[[start],voicings(chords[1]),voicings(chords[2]),voicings(chords[3],true)];
    if(candidates.some(group=>!group.length))throw new Error("Keine gültige Stimmenführung gefunden.");
    let scores=[0], paths=[];
    for(let step=1;step<4;step++) {
      const prev=candidates[step-1], next=candidates[step], newScores=[], links=[];
      for(let i=0;i<next.length;i++) {
        let best=Infinity,bestJ=0;
        for(let j=0;j<prev.length;j++) {
          const score=scores[j]+transition(prev[j],next[i])+staticCost(next[i]);
          if(score<best) {best=score;bestJ=j;}
        }
        newScores.push(best);links.push(bestJ);
      }
      paths.push(links);scores=newScores;
    }
    let index=scores.indexOf(Math.min(...scores)), result=new Array(4);
    for(let step=3;step>=1;step--) {result[step]=candidates[step][index];index=paths[step-1][index];}
    result[0]=start;
    return result;
  }
  function createPuzzle() {
    const chords=[{...C_CHORD},randomMiddle(),randomMiddle(),{...C_CHORD}];
    return {id:++quizSequence,chords,voices:voiceLead(chords),revealed:false};
  }
  function noteLabel(midi,c) {
    const index=c.pcs.indexOf(pc(midi)), name=c.names[index] || "?";
    return `${noteNameShown(name)}${Math.floor(midi/12)-1}`;
  }
  // Die Notenzeile funktioniert auch ohne Netzverbindung. Sobald VexFlow
  // geladen ist, wird sie durch professionellen SVG-Notensatz ersetzt.
  let notationLoadState = "idle";
  const notationUrl = "https://cdn.jsdelivr.net/npm/vexflow@5.0.0/build/cjs/vexflow.js";
  const noteNameShown = name => name === "B" ? "B♭" : name;
  function spelledPitch(name, midi) {
    let letter = name[0].toLowerCase(), accidental = "";
    if (name === "H") letter = "b";
    else if (name === "B") {letter = "b"; accidental = "b";}
    else if (name.endsWith("is")) accidental = "#";
    else if (name.endsWith("es") || name === "As" || name === "Es") accidental = "b";
    return {letter,accidental,octave:Math.floor(midi/12)-1, midi, name};
  }
  function scoreColumns(puzzle) {
    const upperState = new Map(), lowerState = new Map();
    return puzzle.voices.map((four,i)=>{
      const upper=[],lower=[],names=puzzle.chords[i].names,pcs=puzzle.chords[i].pcs;
      four.forEach((midi,index)=>{
        const name=names[pcs.indexOf(pc(midi))];
        const item=spelledPitch(name,midi);
        (index===0 || midi<60 ? lower : upper).push(item);
      });
      for (const [items,state] of [[upper,upperState],[lower,lowerState]]) {
        items.sort((a,b)=>a.midi-b.midi);
        for (const item of items) {
          const key=`${item.letter}/${item.octave}`;
          const before=state.get(key)||"";
          item.visibleAccidental=item.accidental!==before ? (item.accidental||"n") : "";
          state.set(key,item.accidental);
          item.vexKey=`${item.letter}${item.accidental}/${item.octave}`;
        }
      }
      return {upper,lower,label:puzzle.chords[i].label};
    });
  }
  function tryLoadNotation() {
    if (notationLoadState!=="idle") return;
    const vf=global.VexFlow||global.Vex?.Flow;
    if (vf?.StaveNote) {notationLoadState="ready";return;}
    notationLoadState="loading";
    const loader=document.createElement("script");loader.src=notationUrl;loader.async=true;
    loader.addEventListener("load",async()=>{
      const lib=global.VexFlow||global.Vex?.Flow;
      if (!lib?.StaveNote) {notationLoadState="failed";return;}
      try {
        if (typeof lib.loadFonts==="function")await lib.loadFonts("Bravura","Academico");
        if (typeof lib.setFonts==="function")lib.setFonts("Bravura","Academico");
      } catch(e) {console.warn("VexFlow-Schrift: Standardfont wird verwendet.",e);}
      notationLoadState="ready";
      // Die bisherige Ersatzansicht wird ohne Bedienereingriff aktualisiert.
      for (const view of views) {
        const paper=view.querySelector(".hq-score-paper");
        if (paper && quiz.revealed) drawScore(paper,quiz);
      }
    });
    loader.addEventListener("error",()=>{notationLoadState="failed";});
    document.head.append(loader);
  }
  function drawScore(paper,puzzle) {
    if (!paper) return;
    const cols=scoreColumns(puzzle);
    paper.replaceChildren();
    if (notationLoadState==="ready") {
      try {drawVexFlow(paper,cols);return;} catch(e) {
        console.warn("Notensatz: Ersatzansicht wird verwendet.",e);
        notationLoadState="failed";paper.replaceChildren();
      }
    }
    drawSimpleScore(paper,cols);
    tryLoadNotation();
  }
  function drawVexFlow(paper,columns) {
    const V=global.VexFlow||global.Vex?.Flow;
    const width=880,height=317;
    const renderer=new V.Renderer(paper,V.Renderer.Backends.SVG);
    renderer.resize(width,height);
    const context=renderer.getContext();
    const top=new V.Stave(66,36,778),bottom=new V.Stave(66,167,778);
    top.addClef("treble"); bottom.addClef("bass");
    top.setContext(context).draw();bottom.setContext(context).draw();
    try {
      const bracket=new V.StaveConnector(top,bottom).setType(V.StaveConnector.type.BRACE);
      bracket.setContext(context).draw();
      const left=new V.StaveConnector(top,bottom).setType(V.StaveConnector.type.SINGLE_LEFT);
      left.setContext(context).draw();
    }catch{}
    function chordNote(items,clef,stem) {
      const note=new V.StaveNote({keys:items.map(n=>n.vexKey),duration:"q",clef,stem_direction:stem});
      items.forEach((n,i)=>{if (n.visibleAccidental)note.addModifier(new V.Accidental(n.visibleAccidental),i);});
      return note;
    }
    const topNotes=columns.map(x=>chordNote(x.upper,"treble",1));
    const bassNotes=columns.map(x=>chordNote(x.lower,"bass",-1));
    topNotes.forEach(note=>note.setStave(top));
    bassNotes.forEach(note=>note.setStave(bottom));
    const topVoice=new V.Voice({num_beats:4,beat_value:4});topVoice.addTickables(topNotes);
    const bassVoice=new V.Voice({num_beats:4,beat_value:4});bassVoice.addTickables(bassNotes);
    // Die Modifier-Kontexte bleiben für beide Notensysteme getrennt;
    // die Tick-Kontexte richten die vier Akkorde horizontal gemeinsam aus.
    new V.Formatter().joinVoices([topVoice]).joinVoices([bassVoice]).format([topVoice,bassVoice],694);
    topVoice.draw(context,top);bassVoice.draw(context,bottom);
    const svg=paper.querySelector("svg");
    if (!svg)throw new Error("VexFlow hat kein SVG erzeugt.");
    svg.setAttribute("viewBox",`0 0 ${width} ${height}`);
    svg.setAttribute("role","img");
    svg.setAttribute("aria-label","Vier vierstimmige Akkorde in einem System mit Violin- und Bassschlüssel");
    for (let i=0;i<4;i++) {
      const x=topNotes[i].getAbsoluteX();
      const label=document.createElementNS("http://www.w3.org/2000/svg","text");
      label.setAttribute("x",x);label.setAttribute("y",302);label.setAttribute("text-anchor","middle");
      label.setAttribute("font-family","Georgia, serif");label.setAttribute("font-size","17");
      label.setAttribute("fill","#39332e");label.textContent=columns[i].label;
      svg.append(label);
    }
  }
  function drawSimpleScore(paper,columns) {
    // Schmale Offline-Fallback-Partitur mit exakt aus den MIDI-Tönen
    // berechneten Linien-/Zwischenraumlagen und Versetzungszeichen.
    const ns="http://www.w3.org/2000/svg",svg=document.createElementNS(ns,"svg");
    svg.setAttribute("viewBox","0 0 880 311");svg.setAttribute("width","880");svg.setAttribute("height","311");
    svg.setAttribute("role","img");
    svg.setAttribute("aria-label","Vier Akkorde im Violin- und Bassschlüssel, von links nach rechts");
    const add=(tag,atts,content)=>{
      const node=document.createElementNS(ns,tag);
      for (const [key,val] of Object.entries(atts))node.setAttribute(key,String(val));
      if(content!==undefined)node.textContent=content;
      svg.append(node);return node;
    };
    add("rect",{x:0,y:0,width:880,height:311,fill:"#fffdfa"});
    for (const y0 of [48,173]) for(let j=0;j<5;j++) {
      add("line",{x1:65,x2:855,y1:y0+j*12,y2:y0+j*12,stroke:"#2e2926","stroke-width":1.15});
    }
    add("path",{d:"M 56 48 Q 43 48 43 60 L 43 213 Q 43 226 56 221","fill":"none","stroke":"#3b3531","stroke-width":"2.5"});
    add("line",{x1:65,x2:65,y1:48,y2:221,stroke:"#39322c","stroke-width":1.4});
    add("text",{x:72,y:108,"font-family":"Noto Music,FreeSerif,serif","font-size":70,fill:"#27231f"},"𝄞");
    add("text",{x:74,y:210,"font-family":"Noto Music,FreeSerif,serif","font-size":51,fill:"#27231f"},"𝄢");
    const diatonic="cdefgab";
    const heightNumber=p=>p.octave*7+diatonic.indexOf(p.letter);
    // E4 = unterste Linie im Violinschlüssel; G2 = unterste Linie im Bassschlüssel.
    const getY=(item,clef)=> clef==="treble"
      ? 96-(heightNumber(item)-(4*7+2))*6
      : 221-(heightNumber(item)-(2*7+4))*6;
    const xs=[204,406,608,803];
    columns.forEach((col,i)=>{
      for(const [staff,clef,bottom,top] of [[col.upper,"treble",96,48],[col.lower,"bass",221,173]]){
        const pos=staff.map(n=>({n,y:getY(n,clef)}));
        // Bei benachbarten Sekunden werden die Notenköpfe gegeneinander versetzt.
        pos.forEach((item,j)=>{
          const {n,y}=item;
          let x=xs[i];
          if(j && Math.abs(y-pos[j-1].y)<=6.1)x+=15;
          for(let yy=bottom+12;yy<=y+1;yy+=12) {
            if(y>bottom+1)add("line",{x1:x-13,x2:x+13,y1:yy,y2:yy,stroke:"#292521","stroke-width":1.15});
          }
          for(let yy=top-12;yy>=y-1;yy-=12) {
            if(y<top-1)add("line",{x1:x-13,x2:x+13,y1:yy,y2:yy,stroke:"#292521","stroke-width":1.15});
          }
          if(n.visibleAccidental) {
            const glyph={"#":"♯","b":"♭","n":"♮"}[n.visibleAccidental];
            add("text",{x:x-26,y:y+7,"font-family":"Noto Music,FreeSerif,serif","font-size":23,"text-anchor":"middle",fill:"#28231f"},glyph);
          }
          add("ellipse",{cx:x,cy:y,rx:9,ry:5.9,transform:`rotate(-17 ${x} ${y})`,fill:"#26221f"});
          if(j===pos.length-1) {
            const direction=clef==="treble"?1:-1;
            add("line",{x1:x+(direction>0?8:-8),x2:x+(direction>0?8:-8),y1:y,y2:y+(direction>0?-37:37),stroke:"#26221f","stroke-width":1.7});
          }
        });
      }
      add("text",{x:xs[i],y:278,"font-family":"Georgia,serif","font-size":17,"text-anchor":"middle",fill:"#342e2a"},col.label);
    });
    paper.append(svg);
  }

  function clearTimers() {for(const id of timers)clearTimeout(id);timers=[];}
  function stopAudio() {
    epoch++; clearTimers(); playing=false;activeStep=-1;
    if(playBus && ctx) {
      const now=ctx.currentTime;
      playBus.gain.cancelScheduledValues(now);
      playBus.gain.setTargetAtTime(.00001,now,.025);
      const bus=playBus;setTimeout(()=>{try{bus.disconnect();}catch{}},260);
      playBus=null;
    }
    redraw();
  }
  function ensureAudio() {
    if(!ctx){
      const AudioContext=global.AudioContext||global.webkitAudioContext;
      if(!AudioContext)throw new Error("Dieser Browser unterstützt Web Audio nicht.");
      ctx=new AudioContext();
      const delay=ctx.createDelay(.6), feedback=ctx.createGain(),filter=ctx.createBiquadFilter(),wet=ctx.createGain();
      delay.delayTime.value=.19;feedback.gain.value=.22;filter.type="lowpass";filter.frequency.value=2400;wet.gain.value=.16;
      delay.connect(filter);filter.connect(feedback);feedback.connect(delay);delay.connect(wet);wet.connect(ctx.destination);
      ambient=delay;
    }
    return ctx.resume();
  }
  function scheduleNote(midi,when,hold,level,pan=0) {
    const f=440*Math.pow(2,(midi-69)/12),kind=settings.timbre;
    const attack=kind==="warm"?.085:.011;
    const note=ctx.createGain(),release=kind==="organ"?.25:kind==="warm"?.5:.32;
    const volume=kind==="organ"?level*.63:level;
    note.gain.setValueAtTime(.0001,when);
    note.gain.exponentialRampToValueAtTime(volume,when+attack);
    if(kind==="piano")note.gain.exponentialRampToValueAtTime(volume*.20,when+Math.min(hold*.7,.72));
    else if(kind==="warm")note.gain.setTargetAtTime(volume*.66,when+attack,.38);
    const off=when+hold;
    note.gain.setTargetAtTime(.0001,off,release/4);
    let out=note;
    if(ctx.createStereoPanner){const stereo=ctx.createStereoPanner();stereo.pan.value=pan;note.connect(stereo);out=stereo;}
    out.connect(playBus); 
    const partials=kind==="organ"?[[1,1],[2,.26],[3,.12]]:kind==="warm"?[[1,1],[2,.14],[3,.05]]:[[1,1],[2,.27],[3,.13],[4,.045]];
    for(const [partial,amp] of partials){
      const oscillator=ctx.createOscillator(),gain=ctx.createGain();
      oscillator.type="sine";oscillator.frequency.setValueAtTime(f*partial,when);
      // leichte Einschwingdifferenz für ein weniger steriles Timbre
      gain.gain.value=amp*(partial===1?1:.78);
      oscillator.connect(gain);gain.connect(note);
      oscillator.start(when);oscillator.stop(off+Math.max(.45,release*2));
    }
  }
  function scheduleChord(voices,when,duration) {
    for(let i=0;i<4;i++){
      const offset=settings.mode==="broken"?i*.14: i*.009;
      const noteHold=Math.max(.35,duration-(settings.mode==="broken"?offset:.02)-.11);
      scheduleNote(voices[i],when+offset,noteHold,i===0?.105:.055,[-.18,-.12,.11,.26][i]);
    }
  }
  async function play() {
    if(playing){stopAudio();return;}
    stopAudio();
    const requestedEpoch=epoch;
    try{await ensureAudio();}catch(e){if(epoch===requestedEpoch)announce(e.message);return;}
    // Bei einem zweiten schnellen Klick eine überholte Wiedergabe verwerfen.
    if(epoch!==requestedEpoch)return;
    const thisEpoch=epoch, bar=60/settings.bpm*2, start=ctx.currentTime+.06;
    playBus=ctx.createGain();playBus.gain.value=1;playBus.connect(ctx.destination);playBus.connect(ambient);
    playing=true;
    quiz.voices.forEach((v,i)=>{
      scheduleChord(v,start+i*bar,bar);
      timers.push(setTimeout(()=>{if(epoch===thisEpoch){activeStep=i;redraw();}},i*bar*1000+40));
    });
    redraw();
    timers.push(setTimeout(()=>{
      if(epoch!==thisEpoch)return;
      if(settings.repeat){stopAudio();void play();}
      else stopAudio();
    },bar*4*1000+300));
  }
  function announce(text) {
    views.forEach(view=>{const status=view.querySelector(".hq-status");if(status)status.textContent=text;});
  }
  function newPuzzle() {stopAudio();quiz=createPuzzle();redraw();}
  function toggleReveal() {quiz.revealed=!quiz.revealed;redraw();}
  function makeButton(label,klass,listener) {
    const b=document.createElement("button");b.type="button";b.className=klass;b.textContent=label;b.addEventListener("click",listener);return b;
  }
  function makeControl(caption,kind,values,callback) {
    const label=document.createElement("label");label.className="hq-field";
    const name=document.createElement("span");name.textContent=caption;
    const select=document.createElement("select");select.setAttribute("aria-label",caption);
    for(const [value,text] of values){const opt=document.createElement("option");opt.value=value;opt.textContent=text;select.append(opt);}
    select.value=settings[kind];select.addEventListener("change",()=>{
      const chosen=select.value; settings[kind]=chosen; stopAudio();
    });
    label.append(name,select);return label;
  }
  function makeView(large) {
    const root=document.createElement("section");root.className=`hq-player ${large?"hq-large":"hq-small"}`;
    root.setAttribute("aria-label","Akkord-Mystery-Spieler");
    root.innerHTML=`<div class="hq-line"><span>HÖRRÄTSEL · VIERSTIMMIG</span><span class="hq-counter">4 Akkorde</span></div>
      <div class="hq-chords" aria-label="Vier Akkorde; die mittleren sind zunächst verborgen"></div>
      <div class="hq-controls"><div class="hq-primary"></div><div class="hq-actions"></div></div>
      <div class="hq-options"></div><div class="hq-status" aria-live="polite"></div>
      <div class="hq-voices" hidden></div>`;
    const primary=root.querySelector(".hq-primary"),actions=root.querySelector(".hq-actions");
    const playButton=makeButton("▶  Abspielen","hq-play",()=>void play());
    const revealButton=makeButton("Ergebnis zeigen","hq-reveal",toggleReveal);
    const newButton=makeButton("↻  Neue Karte","hq-new",newPuzzle);
    primary.append(playButton);actions.append(revealButton,newButton);
    const options=root.querySelector(".hq-options");
    const speed=document.createElement("label");speed.className="hq-field hq-speed";
    const label=document.createElement("span");label.textContent="Tempo";
    const range=document.createElement("input");range.type="range";range.min="50";range.max="140";range.step="2";range.value=String(settings.bpm);range.setAttribute("aria-label","Tempo in Vierteln pro Minute");
    range.addEventListener("input",()=>{
      const newTempo=Number(range.value);settings.bpm=newTempo;stopAudio();
    });
    const speedValue=document.createElement("output");speedValue.className="hq-bpm";
    speed.append(label,range,speedValue);
    options.append(speed,
      makeControl("Klang","timbre",[["piano","Weicher Klavierton"],["warm","Warmer Synthesizer"],["organ","Orgel"]]),
      makeControl("Spielweise","mode",[["block","Zusammen"],["broken","Leicht gebrochen"]]));
    const repeat=document.createElement("label");repeat.className="hq-repeat";
    const check=document.createElement("input");check.type="checkbox";check.checked=settings.repeat;
    check.addEventListener("change",()=>{settings.repeat=check.checked;redraw();});
    repeat.append(check,document.createTextNode("Wiederholen"));options.append(repeat);
    views.add(root);root._hq={playButton,revealButton,range,speedValue,check};
    updateView(root);
    return root;
  }
  function updateView(root) {
    if(!root.isConnected && root._hq?.seen) {views.delete(root);return;}
    root._hq.seen=true;
    const chords=root.querySelector(".hq-chords");chords.replaceChildren();
    quiz.chords.forEach((c,i)=>{
      const box=document.createElement("div");box.className=`hq-chord${activeStep===i?" hq-active":""}`;
      const number=document.createElement("span");number.className="hq-step";number.textContent=String(i+1).padStart(2,"0");
      const value=document.createElement("strong");
      value.textContent=(i===0||i===3||quiz.revealed)?c.label:"?";
      if((i===1||i===2)&&!quiz.revealed)box.classList.add("hq-secret");
      box.append(number,value);chords.append(box);
    });
    root._hq.playButton.textContent=playing?"■  Stoppen":"▶  Abspielen";
    root._hq.revealButton.textContent=quiz.revealed?"Ergebnis verbergen":"Ergebnis zeigen";
    root._hq.range.value=String(settings.bpm);root._hq.speedValue.textContent=`${settings.bpm} BPM`;
    root._hq.check.checked=settings.repeat;
    root.querySelectorAll("select").forEach(s=>{
      if(s.getAttribute("aria-label")==="Klang")s.value=settings.timbre;
      if(s.getAttribute("aria-label")==="Spielweise")s.value=settings.mode;
    });
    const voices=root.querySelector(".hq-voices");voices.hidden=!quiz.revealed;
    if(quiz.revealed && voices.dataset.quizId!==String(quiz.id)) {
      voices.dataset.quizId=String(quiz.id);voices.replaceChildren();
      const scoreSection=document.createElement("div");scoreSection.className="hq-score-section";
      const heading=document.createElement("h3");heading.className="hq-score-heading";heading.textContent="Partitur · vier Akkorde";
      const scroll=document.createElement("div");scroll.className="hq-score-scroll";scroll.tabIndex=0;scroll.setAttribute("aria-label","Partitur, auf kleinen Bildschirmen seitlich verschiebbar");
      const paper=document.createElement("div");paper.className="hq-score-paper";scroll.append(paper);
      const hint=document.createElement("p");hint.className="hq-score-hint";hint.textContent="Violin- und Bassschlüssel · vierstimmig · bei Bedarf seitlich wischen";
      scoreSection.append(heading,scroll,hint);voices.append(scoreSection);
      drawScore(paper,quiz);
      const head=document.createElement("p");head.className="hq-voices-head";head.textContent="Realisiert im vierstimmigen Satz · klingende Tonhöhe";voices.append(head);
      const grid=document.createElement("div");grid.className="hq-voice-grid";
      for(let i=0;i<4;i++){
        const cell=document.createElement("div");cell.className="hq-voice-cell";
        const title=document.createElement("b");title.textContent=`${i+1}. ${quiz.chords[i].label}`;
        const notes=document.createElement("span");notes.textContent=quiz.voices[i].map((n,v)=>`${voiceLabels[v]} ${noteLabel(n,quiz.chords[i])}`).join(" · ");
        cell.append(title,notes);grid.append(cell);
      }
      voices.append(grid);
    }
  }
  function redraw() {for(const view of [...views])updateView(view);}
  function mount(host,large=false) {const view=makeView(large);host.append(view);return view;}
  quiz=createPuzzle();
  // Eine dynamische Karte wird dem vorhandenen statischen Kartensatz hinzugefügt,
  // noch bevor dessen Feed und Kategorien aufgebaut werden.
  if (Array.isArray(global.KARTEN) && !global.KARTEN.some(card=>card.kind==="harmony-quiz")) {
    global.KARTEN.push({category:CATEGORY,kind:"harmony-quiz",title:"Akkord-Mystery",
      summary:"C – ? – ? – C. Vierstimmige Akkordfolge hören und die Zwischenakkorde samt Basslagen erraten.",
      detail:[], media:[]});
  }
  global.HARMONY_QUIZ={mount,stop:stopAudio,newPuzzle,
    getPuzzle:()=>({chords:quiz.chords.map(c=>({...c})),voices:quiz.voices.map(v=>[...v]),revealed:quiz.revealed}),
    _test:{chord,voicings,transition,voiceLead,createPuzzle}};
})(window);
